module.exports = {
  MONGOURI: process.env.MONGOURI,
};
