# Basic-Banking-System
T.S.F. Banking is a basic banking system. It's objective is to demonstrate the real banking procedure. Operations like transfer money, see all customers. The website also allows users to check their transaction history.

-------------------------------------------------------------------------------------------------------

### [Live Site](https://tsf-basic-banking-system-84.herokuapp.com/)

-------------------------------------------------------------------------------------------------------

### Tech Stack Used
MERN Stack

-------------------------------------------------------------------------------------------------------

### Deployed On Heroku

